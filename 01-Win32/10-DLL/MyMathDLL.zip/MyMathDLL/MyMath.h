#pragma once
extern "C" int MakeSquare(int);


