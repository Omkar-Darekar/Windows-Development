#pragma once
extern "C" void MakeSquare(int);



